# analytics/ (derived layer)

This layer is intentionally **optional** during scraping. It is fully derivable from core/ + dictionaries/ + manifest/.

Included here as skeleton only (no data).
